<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>String</title>
</head>
<body>
    <?php
        // variável do tipo String
             $nome = 'Meu nome 123';
             echo "$nome";
             echo"<br>";

        // variável do tipo inteiro
             $ano = 2023;
             echo "$ano";
             echo"<br>";

         // variável do tipo float
             $pi = 3.14159265;
             echo "$pi";
             echo"<br>";

        // variável do tipo booleano
             $sim = true;
             echo "$sim";
    
    ?>
</body>
</html>
